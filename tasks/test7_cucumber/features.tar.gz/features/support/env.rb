require 'selenium-webdriver'
require 'rspec/expectations'
require 'test-unit'
require 'test/unit'
require 'watir-webdriver'
require 'rspec'
require 'cucumber'


World(RSpec::Matchers) #to make rspec matchers work